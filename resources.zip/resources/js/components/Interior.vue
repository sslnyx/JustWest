<template>
  <div class="content">
    <h1 class="text-center">
      HIGH DESIGN,
      <span>MODERN LIVING</span>
    </h1>
    <b-row class="kitchen-wrapper m-0">
      <div class="tab-wood">
        <div>Wood</div>
        <div>SEE ALTERNATE COLOR</div>
      </div>
      <div class="plus"></div>
      <img src="img/full/doll/rendering_01_kitchen_a.jpg" alt="kitchen" />
    </b-row>

    <b-row class="m-0">
      <b-col cols="12" md="6" class="d-flex align-items-center">
        <div class="p-3 p-md-5">
          <p>With contemporary white brick exteriors surrounded by lush landscaping, Just West beautifully complements its iconic west-side setting. Here, smart architectural design maximizes indoor-outdoor living with balconies, patios, or rooftop decks in each home.</p>
          <p>At its core, Just West has been designed to foster a strong sense of community amongst neighbours. The amenity-rich courtyard is the perfect setting for connecting where you can dine at the harvest-style table, cozy up to the fire pit or lounge in front of the outdoor movie screen with family and friends alike.</p>
        </div>
      </b-col>
      <b-col cols="12" md="6" class="interior-containter p-0">
        <div class="interior-wrapper">
          <div class="tab-wood">
            <div>Wood</div>
            <div>SEE ALTERNATE COLOR</div>
          </div>
          <img src="img/full/doll/rendering_01_kitchen_a.jpg" alt="kitchen" />
        </div>
        <div class="interior-wrapper">
          <div class="tab-wood">
            <div>Wood</div>
            <div>SEE ALTERNATE COLOR</div>
          </div>
          <img src="img/full/doll/rendering_01_kitchen_a.jpg" alt="kitchen" />
        </div>
      </b-col>
    </b-row>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>