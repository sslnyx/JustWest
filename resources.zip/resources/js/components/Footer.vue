<template>
  <footer class="site-footer">
    <b-row>
      <b-col class="p-0">
        <a href="https://www.sightlineproperties.ca">
          <img src="img/full/icon/00_logo.svg" class="site-logo" alt="site logo" />
        </a>
      </b-col>

      <b-col>
        <div class="address">
          <h6>PRESENTATION CENTRE</h6>
          <p>
            479 West 16th Ave, Vancouver
            <br />By appointment
            <br />604.734.8883
            <br />
            <a href="mailto:info@justwest.ca">info@justwest.ca</a>
          </p>
        </div>
      </b-col>

      <b-col cols="12" md="auto" class="text-center text-md-left">
        <div class="h-100">
          <h6>Developed by</h6>
          <div class="logo-wrapper">
            <img
              class="footer-developer"
              src="img/full/developer/sightline.svg"
              alt="sightline.svg"
            />
          </div>
        </div>
      </b-col>

      <b-col cols="12" md="auto" class="text-center text-md-left mb-5 mb-md-0">
        <div class="h-100">
          <h6>Marketing & Sales by</h6>
          <div class="logo-wrapper">
            <img class="ph-logo" src="img/full/icon/footer_logo_pilothouse.svg" alt />
          </div>
        </div>
      </b-col>
    </b-row>
  </footer>
</template>

<script>
export default {};
</script>

<style>
</style>