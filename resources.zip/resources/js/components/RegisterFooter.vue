<template>
  <footer class="mt-0 p-3 p-md-0">
      <b-row class="align-items-center">
        <b-col cols="12" md="8" class="footer-info">
          This is not an offering for sale. Any such offering can only be made with the applicable disclosure statement and agreement of purchase and
          sale. Marketing and sales by Macdonald Realty Platinum Project Marketing.
          <a
            href="http://pilothouseinc.com/"
            target="_blank"
          >www.pilothouseinc.com</a>. E.&amp;O.E.
        </b-col>
        <b-col cols="12" md="4" class="d-flex">
          <a href="https://sightlineproperties.ca/" class="d-flex" target="_blank">
            <img src="img/landing/00_dev_sightline.svg" alt="developer-logo" />
          </a>
          <a href="http://pilothouseinc.com" target="_blank">
            <img src="img/landing/00_dev_Pilothouse.svg" alt="developer-logo" />
          </a>
        </b-col>
      </b-row>
    </footer>
</template>

<script>
export default {

}
</script>

<style>

</style>